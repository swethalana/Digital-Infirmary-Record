package Project;
import java.sql.*;




public class ConnectionProvider {
public static Connection getcon()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver:");
            Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/project","root","infirmary@@123");
            return con;
        }
        catch(Exception e)
        {
            return null;
        }
    }

   public static Connection getCon() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    

    

   
}
